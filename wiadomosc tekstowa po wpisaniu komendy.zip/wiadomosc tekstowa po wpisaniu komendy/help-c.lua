RegisterCommand("Komenda na jaka ma odpowiadac", function()

msg(tu wiadomość jaką chcesz wyswietlic po napisaniu komendy)
msg(tu te mozesz robic ile chcesz wiadomosci)
end, false)

function msg(text)
    TriggerEvent("chatmessage", :[Server]", {255,0,0}, text)
end